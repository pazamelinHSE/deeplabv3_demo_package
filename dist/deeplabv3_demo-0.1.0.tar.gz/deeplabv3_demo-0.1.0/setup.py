# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['deeplabv3_demo']

package_data = \
{'': ['*'], 'deeplabv3_demo': ['resources/img/*', 'resources/models/*']}

install_requires = \
['argparse>=1.4.0,<2.0.0',
 'numpy>=1.24.2,<2.0.0',
 'opencv-python>=4.7.0.68,<5.0.0.0',
 'pillow>=9.4.0,<10.0.0',
 'tensorflow>=2.11.0,<3.0.0']

entry_points = \
{'console_scripts': ['demo = deeplabv3_demo.demo:run']}

setup_kwargs = {
    'name': 'deeplabv3-demo',
    'version': '0.1.0',
    'description': '',
    'long_description': '# deeplabv3_demo_package\nDemo package with quantized Deeplab-V3+ model for semantic image segmentation.\n\n## Installation\n```console\n$ pip3 install git+https://github.com/pazamelin/deeplabv3_demo_package.git@week1\n```\n\n## Run demo without any arguments\n```console\n$ demo\n```\nyou should get the following result:\n\n<img src="demo-result.png" width=800 height=400>\n\n## Run demo with --help to get arguments list\n```console\n$ demo --help\n```\n\n## Run demo a custom image\n```console\n$ demo --img <IMG-PATH>\n```\n\n## Uninstall the package\n```console\n$ pip3 uninstall deeplabv3-demo\n',
    'author': 'None',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<3.12',
}


setup(**setup_kwargs)
